# Hello Widget Plugin Template

This is a ready-to-zip template plugin.

## Install (ZIP)
- Zip the `hello_widget` folder so it is the root of the ZIP.
- Upload via Admin Settings -> Plugins.

## Install (Local)
- Copy this folder to `plugins/installed/hello_widget/`
- Use "Plugins entdecken" in Settings.
